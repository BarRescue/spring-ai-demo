package nl.expertlycoded.coursechat;

import java.util.Arrays;

import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.ai.tool.metadata.ToolMetadata;

/**
 * Decorator around a set of tools: logs every call and records it in the {@link ToolCallLog}.
 */
class LoggingToolCallbackProvider implements ToolCallbackProvider {

    private static final Logger log = LoggerFactory.getLogger(LoggingToolCallbackProvider.class);

    private final ToolCallbackProvider delegate;
    private final ToolCallLog toolCallLog;

    LoggingToolCallbackProvider(ToolCallbackProvider delegate, ToolCallLog toolCallLog) {
        this.delegate = delegate;
        this.toolCallLog = toolCallLog;
    }

    @Override
    public ToolCallback[] getToolCallbacks() {
        return Arrays.stream(delegate.getToolCallbacks())
                .map(LoggingToolCallback::new)
                .toArray(ToolCallback[]::new);
    }

    private final class LoggingToolCallback implements ToolCallback {

        private final ToolCallback delegate;

        LoggingToolCallback(ToolCallback delegate) {
            this.delegate = delegate;
        }

        @Override
        public ToolDefinition getToolDefinition() {
            return delegate.getToolDefinition();
        }

        @Override
        public ToolMetadata getToolMetadata() {
            return delegate.getToolMetadata();
        }

        @Override
        public String call(String toolInput) {
            return call(toolInput, null);
        }

        @Override
        public String call(String toolInput, @Nullable ToolContext toolContext) {
            var name = delegate.getToolDefinition().name();
            log.info("Tool called: {}({})", name, toolInput);
            toolCallLog.record(name, toolInput);
            return delegate.call(toolInput, toolContext);
        }
    }
}
