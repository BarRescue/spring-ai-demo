package nl.expertlycoded.coursechat;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class ChatConfig {

    private static final String SYSTEM_PROMPT = """
            You are the course assistant of a training institute.
            Always answer questions about the course catalog using the available tools;
            never make up courses, prices or dates. Prices are in EUR, excluding VAT.
            When the user asks for an image or visual, use the generate_image tool. If the image
            is about a course, look up the course details first so the image matches the course.
            Answer in English, briefly and concretely.""";

    /**
     * The ChatClient talks to the OpenAI model. The course tools do not live in this app;
     * they are fetched over MCP from the course-mcp-server (Spring AI auto-configures
     * the SyncMcpToolCallbackProvider based on application.yaml). The image tool is a
     * local tool in this app.
     */
    @Bean
    ChatClient chatClient(ChatClient.Builder builder, SyncMcpToolCallbackProvider mcpTools,
                          ImageTools imageTools, ToolCallLog toolCallLog, ChatMemory chatMemory) {
        var localTools = MethodToolCallbackProvider.builder().toolObjects(imageTools).build();
        return builder
                .defaultSystem(SYSTEM_PROMPT)
                .defaultToolCallbacks(
                        new LoggingToolCallbackProvider(mcpTools, toolCallLog),
                        new LoggingToolCallbackProvider(localTools, toolCallLog))
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())
                .build();
    }
}
