@NullMarked
package nl.expertlycoded.coursechat;

import org.jspecify.annotations.NullMarked;
