package nl.expertlycoded.coursechat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseChatClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseChatClientApplication.class, args);
    }
}
