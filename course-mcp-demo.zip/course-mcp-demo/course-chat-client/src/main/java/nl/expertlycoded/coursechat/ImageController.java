package nl.expertlycoded.coursechat;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Direct text -> image endpoint (without the chat model in between), plus serving
 * the generated images.
 */
@RestController
@RequestMapping("/api/images")
class ImageController {

    record ImageRequest(String prompt) {}

    private final ImageService imageService;

    ImageController(ImageService imageService) {
        this.imageService = imageService;
    }

    @PostMapping
    ImageService.GeneratedImage generate(@RequestBody ImageRequest request) {
        try {
            return imageService.generate(request.prompt());
        } finally {
            imageService.drainGeneratedInRequest();
        }
    }

    @GetMapping("/{id}")
    ResponseEntity<byte[]> image(@PathVariable String id) {
        return imageService.find(id)
                .map(bytes -> ResponseEntity.ok()
                        .contentType(MediaType.IMAGE_PNG)
                        .body(bytes))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
