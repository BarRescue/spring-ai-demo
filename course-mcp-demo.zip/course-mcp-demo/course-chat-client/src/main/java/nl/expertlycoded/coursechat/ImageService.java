package nl.expertlycoded.coursechat;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.image.ImageModel;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.stereotype.Service;

/**
 * Generates images with the OpenAI image model (text -> image).
 *
 * <p>Models like gpt-image-1 return the image as base64. We keep those bytes in memory
 * and serve them at {@code /api/images/{id}}, so neither the chat model nor the browser
 * has to deal with megabytes of base64. Fine for a demo; use object storage in production.
 */
@Service
public class ImageService {

    public record GeneratedImage(String id, String url, String prompt) {}

    private static final Logger log = LoggerFactory.getLogger(ImageService.class);
    private static final int MAX_STORED_IMAGES = 50;

    private final ImageModel imageModel;

    /** Simple LRU store: the oldest images are dropped once the limit is reached. */
    private final Map<String, byte[]> store = Collections.synchronizedMap(
            new LinkedHashMap<>(16, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, byte[]> eldest) {
                    return size() > MAX_STORED_IMAGES;
                }
            });

    /** Images generated during the current request, so the chat response can include them. */
    private final ThreadLocal<List<GeneratedImage>> generatedInRequest = ThreadLocal.withInitial(ArrayList::new);

    public ImageService(ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    public GeneratedImage generate(String prompt) {
        log.info("Generating image: {}", prompt);
        var output = imageModel.call(new ImagePrompt(prompt)).getResult().getOutput();
        var id = UUID.randomUUID().toString();

        String url;
        if (output.getB64Json() != null && !output.getB64Json().isBlank()) {
            store.put(id, Base64.getDecoder().decode(output.getB64Json()));
            url = "/api/images/" + id;
        } else if (output.getUrl() != null && !output.getUrl().isBlank()) {
            url = output.getUrl(); // e.g. dall-e-3 returns a (temporary) URL
        } else {
            throw new IllegalStateException("The image model returned no image");
        }

        var image = new GeneratedImage(id, url, prompt);
        generatedInRequest.get().add(image);
        return image;
    }

    public Optional<byte[]> find(String id) {
        return Optional.ofNullable(store.get(id));
    }

    List<GeneratedImage> drainGeneratedInRequest() {
        var result = List.copyOf(generatedInRequest.get());
        generatedInRequest.remove();
        return result;
    }
}
