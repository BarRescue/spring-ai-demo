package nl.expertlycoded.coursechat;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

/**
 * A local tool (not MCP) that lets the chat model generate images. Combined with the
 * MCP course tools, the model can e.g. look up a course and then create a promo image for it.
 */
@Component
class ImageTools {

    private final ImageService imageService;

    ImageTools(ImageService imageService) {
        this.imageService = imageService;
    }

    @Tool(name = "generate_image",
            description = """
                    Generates an image from a text description and shows it to the user. \
                    Use this when the user asks for an image, illustration, banner or visual. \
                    Write a detailed prompt in English describing subject, style and composition.""")
    String generateImage(@ToolParam(description = "Detailed description of the image to generate") String prompt) {
        var image = imageService.generate(prompt);
        // Keep the result short: the image itself is shown in the UI, not sent back to the model.
        return "The image was generated and is already shown to the user (id: " + image.id()
                + "). Do not include a link or markdown image; just briefly describe what was created.";
    }
}
