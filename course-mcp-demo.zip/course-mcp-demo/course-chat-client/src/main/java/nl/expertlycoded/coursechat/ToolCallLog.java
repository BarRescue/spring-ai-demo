package nl.expertlycoded.coursechat;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

/**
 * Tracks per request which MCP tools the model called, so the demo can show it.
 * This works because the synchronous ChatClient executes tool calls on the same
 * thread as the HTTP request.
 */
@Component
public class ToolCallLog {

    public record ToolCall(String tool, String arguments) {}

    private final ThreadLocal<List<ToolCall>> calls = ThreadLocal.withInitial(ArrayList::new);

    void record(String tool, String arguments) {
        calls.get().add(new ToolCall(tool, arguments));
    }

    List<ToolCall> drain() {
        var result = List.copyOf(calls.get());
        calls.remove();
        return result;
    }
}
