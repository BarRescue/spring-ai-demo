package nl.expertlycoded.coursechat;

import java.util.List;
import java.util.UUID;

import org.jspecify.annotations.Nullable;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/chat")
class ChatController {

    record ChatRequest(String message, @Nullable String conversationId) {}

    record ChatResponse(String answer, String conversationId, List<ToolCallLog.ToolCall> toolCalls,
                        List<ImageService.GeneratedImage> images) {}

    private final ChatClient chatClient;
    private final ToolCallLog toolCallLog;
    private final ImageService imageService;

    ChatController(ChatClient chatClient, ToolCallLog toolCallLog, ImageService imageService) {
        this.chatClient = chatClient;
        this.toolCallLog = toolCallLog;
        this.imageService = imageService;
    }

    @PostMapping
    ChatResponse chat(@RequestBody ChatRequest request) {
        var conversationId = request.conversationId() != null && !request.conversationId().isBlank()
                ? request.conversationId()
                : UUID.randomUUID().toString();

        // start with a clean slate for this request
        toolCallLog.drain();
        imageService.drainGeneratedInRequest();
        try {
            var answer = chatClient.prompt()
                    .user(request.message())
                    .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                    .call()
                    .content();
            return new ChatResponse(answer == null ? "" : answer, conversationId,
                    toolCallLog.drain(), imageService.drainGeneratedInRequest());
        } finally {
            toolCallLog.drain();
            imageService.drainGeneratedInRequest();
        }
    }
}
