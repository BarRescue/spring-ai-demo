# Course Chat Client (demo)

Spring Boot 4.1 + Spring AI 2.0 chat client that calls an **OpenAI model**. The tools do not
live in this app: they are fetched over **MCP** from `course-mcp-server`. This shows that the
same MCP server works with Claude as well as with an OpenAI model.

It can also generate images (text → image) with OpenAI's image model: as a tool the chat
model can call ("Create a promotional banner for AI-301"), and as a direct endpoint.

```
Browser ──► course-chat-client (8081) ──► OpenAI API (chat + images)
                     │
                     └── MCP (Streamable HTTP) ──► course-mcp-server (8080)/mcp
```

## Running

1. Start the MCP server first (the client connects to it on startup):
   ```bash
   cd ../course-mcp-server && mvn spring-boot:run
   ```
2. Set your API key and start the client:
   ```bash
   export OPENAI_API_KEY=sk-...
   mvn spring-boot:run
   ```
3. Open http://localhost:8081 and ask a question.

## Configuration (environment variables)

| Variable | Default | |
|---|---|---|
| `OPENAI_API_KEY` | placeholder | Your OpenAI key — required to actually chat |
| `OPENAI_MODEL` | `gpt-5-mini` | Any OpenAI model that supports tool calling |
| `OPENAI_IMAGE_MODEL` | `gpt-image-1` | Image model (e.g. `dall-e-3` also works) |
| `OPENAI_IMAGE_SIZE` | `1024x1024` | e.g. `1536x1024` for a landscape banner (gpt-image-1) |
| `COURSE_MCP_URL` | `http://localhost:8080` | Base URL of the MCP server |

## API

```bash
curl localhost:8081/api/chat -H 'Content-Type: application/json' \
  -d '{"message":"Which AI courses are available?"}'
```

Response:

```json
{
  "answer": "There are two AI courses: ...",
  "conversationId": "ebb9db4f-...",
  "toolCalls": [{ "tool": "search_courses", "arguments": "{\"category\": \"AI\"}" }]
}
```

Send the `conversationId` along with a follow-up question and the model remembers the
conversation (in memory, last 20 messages). If the model generated images, they are listed
in `images` (`[{ "id", "url", "prompt" }]`).

### Text → image directly

```bash
curl localhost:8081/api/images -H 'Content-Type: application/json' \
  -d '{"prompt":"A friendly robot teaching a classroom, flat illustration"}'
# → { "id": "...", "url": "/api/images/<id>", "prompt": "..." }
```

Open `http://localhost:8081/api/images/<id>` to view the PNG. Generating an image takes
roughly 10–60 seconds. Note: OpenAI may require organization verification before you can
use `gpt-image-1`; if so, set `OPENAI_IMAGE_MODEL=dall-e-3`.

## How it works

- `spring-ai-starter-mcp-client` opens an MCP connection based on `application.yaml` and
  provides a `SyncMcpToolCallbackProvider` with all of the server's tools.
- `ChatConfig` attaches those tools to the `ChatClient`, along with a system prompt and chat memory.
- `ImageTools` is a local `@Tool` (`generate_image`) next to the MCP tools; `ImageService` calls
  the OpenAI image model and keeps generated images in memory (last 50), served by `ImageController`.
  The model gets a short text result back, not the image itself, to keep tokens low.
- `LoggingToolCallbackProvider` logs every tool call (`Tool called: ...` in the console)
  and returns them in the response. The chat page shows them as 🔧 lines — handy for the demo.
